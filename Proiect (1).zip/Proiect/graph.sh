#!/bin/bash

#Fisierul in care se afla datele ce trebuie introduse in grafic
logfile=resurse.csv
#Data si timestamp-ul curent pentru a putea crea png-urile corespunzatoare rapoartelor in functie de momentul rularii scriptului
current_date_time=$(date +"%Y-%m-%d_%H:%M:%S")

# Cream un script gnuplot si setam detaliile cum ar fi numele axelor si dimesniunea png-urilor
gnuplot_script="set datafile separator ','
set timefmt '%Y-%m-%d %H:%M:%S'
set xdata time

set ylabel 'Usage'
set xlabel 'Time'
set term png
set terminal png size 1500,1000
set size ratio 0.8
set output 'cpu_usage_$current_date_time.png'
plot '$logfile' using 1:2 with lines title 'CPU Usage'
set output 'cpu_system_$current_date_time.png'
plot '$logfile' using 1:3 with lines title 'CPU System'
set output 'cpu_other_$current_date_time.png'
plot '$logfile' using 1:4 with lines title 'CPU Other'
set output 'memory_usage_$current_date_time.png'
plot '$logfile' using 1:5 with lines title 'Memory Usage'
set output 'io_read_$current_date_time.png'
plot '$logfile' using 1:8 with lines title 'I/O Read Rate'
set output 'io_write_$current_date_time.png'
plot '$logfile' using 1:9 with lines title 'I/O Write Rate'
set output 'bandwidth_in_$current_date_time.png'
plot '$logfile' using 1:10 with lines title 'Bandwidth In'
set output 'bandwidth_out_$current_date_time.png'
plot '$logfile' using 1:11 with lines title 'Bandwidth Out'"

# Rularea scriputului gnuplot
echo "$gnuplot_script" | gnuplot
