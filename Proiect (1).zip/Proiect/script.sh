#!/bin/bash

# Setam intervalul, in secunde, la care se da refresh la date
interval=20


# Setam formatul datei curente pentru a putea vizualiza raportul 
date_format="%Y-%m-%d %H:%M:%S"

#Setam numele coloanelor pe care le va contine csv-ul cu date
echo "Timestamp, CPU Usage, CPU System, CPU Other, Memory Usage Percentage, Memory Total, Memory Used, I/O Read Rate, I/O Write Rate, Bandwidth In, Bandwidth Out " > resurse.csv

while :
do    # Obtinem data curenta sub formatul ales anteror 
    timestamp=$(date +"$date_format")

    # Utilizarea CPU
    
    #Timpul total alocat proceselor utilizator
   cpu_usage=$(top -b -n 1 | grep "Cpu(s)" | awk '{print $2 + $4}')
   #Timpul total acordat sisemului
   cpu_system=$(top -b -n 1 | grep "Cpu(s)" | awk '{print $3 + $7 + $8}')
   #Timpul pentru alte operatii cum ar fi tratarea intreruperilor, timp de inactivitate
   cpu_other=$(top -b -n 1 | grep "Cpu(s)" | awk '{print $5 + $6 + $9}')
   
   
    #Utilizarea memoriei
    
    #Procentjul de utilizare al memoriei
    memory_usage=$(free -m | grep "Mem" | awk '{print $3/$2 * 100.0}')
    #Capacitatea totala a memoriei
    memory_total=$(free -m | grep "Mem" | awk '{print $2}')
    #Spatiul de memorie ocupat 
    memory_used=$(free -m | grep "Mem" | awk '{print $3}')
    
    #Utilizarea dispozitivelor I/O
    
    #Timpul acordat pentru read requests
    io_read=$(cat /sys/block/sda/stat | awk '{print $4}')
    #Timpul acordat pentru write requests
    io_write=$(cat /sys/block/sda/stat | awk '{print $8}')

    #Utilizarea latimii de banda 
    
    #Viteza de primire 
    bandwidth_in=$(cat /sys/class/net/enp0s3/statistics/rx_bytes)
    #Viteza de trasnmitere
    bandwidth_out=$(cat /sys/class/net/enp0s3/statistics/tx_bytes)
    
    # Scriem datele in fisierul resurse.csv ce contorizeaza informatiile colectate pe parcursul unei singure rulari a scriptului pentru a putea vizualiza graficul aferent
    #Scriem datele in fisierul istoric.csv ce contorizeaza informatiile colectate pe parcursul tuturor rularilor scriptului pentru a putea vizualiza graficul aferent
    echo "$timestamp, $cpu_usage, $cpu_system, $cpu_other, $memory_usage, $memory_total, $memory_used, $io_read, $io_write, $bandwidth_in, $bandwidth_out" >> resurse.csv
    echo "$timestamp, $cpu_usage, $cpu_system, $cpu_other, $memory_usage, $memory_total, $memory_used, $io_read, $io_write, $bandwidth_in, $bandwidth_out" >> istoric.csv
    sleep $interval
done
